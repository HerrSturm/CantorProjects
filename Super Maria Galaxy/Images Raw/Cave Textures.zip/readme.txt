Alright so I need some feedback and I only ask that you give reasons why  you like it and why you don't :)

This is my first time making art and publishing it to the public so please be honest with me :P

Here are 9 textures of: Stone, Coal, Iron, and Diamond along with an extra 3 textures for their blocks: Coal ore, Iron ore, Diamond ore.

I hope you enjoy these :D

Copyright:
The only copyright is don't copy my work and sell it as your own!  You don't need to put me in credits but if you're willing to please put me down as Mike Fozzy :')

